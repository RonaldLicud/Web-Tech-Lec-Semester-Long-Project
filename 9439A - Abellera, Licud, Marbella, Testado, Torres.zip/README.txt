Software to use:
NetBeans IDE

Description:
Webtek Lecture Notes makes use of JSP to implement
a simple search functionality that uses a very
simple contains-this-tag mechanic.

Set-up:
1. Start NetBeans IDE.
2. Import the project folder.
3. Run the project.

PS:
The website's course notes can still be accessed
through the html files. Not running a server simply
makes the jsp search functionality not work.